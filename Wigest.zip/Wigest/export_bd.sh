#!/bin/bash
# Export exhaustif des données PostgreSQL en XML via shell
# Nécessite : pg_dump, xmlstarlet

# Variables
DB="wigest"
USER="postgres"
HOST="localhost"
OUT="export_bd.xml"

echo '<?xml version="1.0" encoding="UTF-8"?>' > $OUT
echo '<clients>' >> $OUT

psql -U $USER -h $HOST -d $DB -Atc "SELECT id, nom, email FROM clients" | while IFS='|' read -r cid nom email; do
  echo "  <client id=\"$cid\">" >> $OUT
  echo "    <nom>$nom</nom>" >> $OUT
  echo "    <email>$email</email>" >> $OUT
  echo "    <abonnements>" >> $OUT

  psql -U $USER -h $HOST -d $DB -Atc "SELECT id, offre_id, date_debut, date_fin FROM abonnements WHERE client_id = $cid" | while IFS='|' read -r aid offre_id date_debut date_fin; do
    echo "      <abonnement id=\"$aid\">" >> $OUT
    echo "        <offre_id>$offre_id</offre_id>" >> $OUT
    echo "        <date_debut>$date_debut</date_debut>" >> $OUT
    echo "        <date_fin>$date_fin</date_fin>" >> $OUT
    echo "        <paiements>" >> $OUT

    psql -U $USER -h $HOST -d $DB -Atc "SELECT id, montant, date_paiement FROM paiements WHERE abonnement_id = $aid" | while IFS='|' read -r pid montant date_paiement; do
      echo "          <paiement id=\"$pid\">" >> $OUT
      echo "            <montant>$montant</montant>" >> $OUT
      echo "            <date_paiement>$date_paiement</date_paiement>" >> $OUT
      echo "          </paiement>" >> $OUT
    done

    echo "        </paiements>" >> $OUT
    echo "      </abonnement>" >> $OUT
  done

  echo "    </abonnements>" >> $OUT
  echo "  </client>" >> $OUT
done

echo '</clients>' >> $OUT
echo "Export XML terminé : $OUT"
