<?php
require 'db.php';
header('Content-Type: application/json');

// Ajouter un abonnement
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);
    // Validation des champs requis
    if (!isset($data['client_id']) || !isset($data['offre_id']) || !isset($data['date_debut'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Champs client_id, offre_id et date_debut requis']);
        exit;
    }
    $stmt = $pdo->prepare("INSERT INTO abonnements (client_id, offre_id, date_debut, date_fin) VALUES (?, ?, ?, ?) RETURNING id");
    $stmt->execute([
        $data['client_id'],
        $data['offre_id'],
        $data['date_debut'],
        isset($data['date_fin']) ? $data['date_fin'] : null
    ]);
    $id = $stmt->fetchColumn();
    echo json_encode(['id' => $id]);
    exit;
}

// Supprimer un abonnement
if ($_SERVER['REQUEST_METHOD'] === 'DELETE' && isset($_GET['id'])) {
    $stmt = $pdo->prepare("DELETE FROM abonnements WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    echo json_encode(['status' => 'supprimé']);
    exit;
}
?>