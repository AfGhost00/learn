<?php
require 'db.php';
header('Content-Type: application/json');

// Ajouter un client
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);
    if (!isset($data['nom']) || !isset($data['email']) || empty($data['nom']) || empty($data['email'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Champs nom et email requis']);
        exit;
    }
    try {
        $stmt = $pdo->prepare("INSERT INTO clients (nom, email) VALUES (?, ?) RETURNING id");
        $stmt->execute([$data['nom'], $data['email']]);
        $id = $stmt->fetchColumn();
        echo json_encode(['id' => $id]);
    } catch (PDOException $e) {
        if ($e->getCode() == '23505') { // Unique violation
            http_response_code(409);
            echo json_encode(['error' => "L'email existe déjà"]);
        } else {
            http_response_code(500);
            echo json_encode(['error' => 'Erreur serveur', 'details' => $e->getMessage()]);
        }
    }
    exit;
}

// Supprimer un client
if ($_SERVER['REQUEST_METHOD'] === 'DELETE' && isset($_GET['id'])) {
    $stmt = $pdo->prepare("DELETE FROM clients WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    echo json_encode(['status' => 'supprimé']);
    exit;
}
?>