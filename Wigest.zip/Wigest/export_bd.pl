#!/usr/bin/perl
use strict;
use warnings;
use DBI;
use XML::Writer;
use IO::File;

my $dbh = DBI->connect('dbi:Pg:dbname=wigest;host=localhost', 'postgres', 'pass', { RaiseError => 1, AutoCommit => 1 });
my $output = IO::File->new(">export_bd_perl.xml");
my $writer = XML::Writer->new(OUTPUT => $output, DATA_MODE => 1, DATA_INDENT => 2);

$writer->xmlDecl('UTF-8');
$writer->startTag('database');

my $sth_clients = $dbh->prepare('SELECT id, nom, email FROM clients');
$sth_clients->execute();
while (my $client = $sth_clients->fetchrow_hashref) {
  $writer->startTag('client', id => $client->{id});
  $writer->dataElement('nom', $client->{nom});
  $writer->dataElement('email', $client->{email});

  my $sth_abos = $dbh->prepare('SELECT id, offre_id, date_debut, date_fin FROM abonnements WHERE client_id = ?');
  $sth_abos->execute($client->{id});
  $writer->startTag('abonnements');
  while (my $abo = $sth_abos->fetchrow_hashref) {
    $writer->startTag('abonnement', id => $abo->{id});
    $writer->dataElement('offre_id', $abo->{offre_id});
    $writer->dataElement('date_debut', $abo->{date_debut});
    $writer->dataElement('date_fin', $abo->{date_fin});

    my $sth_paiements = $dbh->prepare('SELECT id, montant, date_paiement FROM paiements WHERE abonnement_id = ?');
    $sth_paiements->execute($abo->{id});
    $writer->startTag('paiements');
    while (my $paiement = $sth_paiements->fetchrow_hashref) {
      $writer->startTag('paiement', id => $paiement->{id});
      $writer->dataElement('montant', $paiement->{montant});
      $writer->dataElement('date_paiement', $paiement->{date_paiement});
      $writer->endTag('paiement');
    }
    $writer->endTag('paiements');
    $sth_paiements->finish;

    $writer->endTag('abonnement');
  }
  $writer->endTag('abonnements');
  $sth_abos->finish;

  $writer->endTag('client');
}
$sth_clients->finish;

$writer->endTag('database');
$writer->end();
$output->close;
$dbh->disconnect;

print "Export XML terminé : export_bd_perl.xml\n";
