from fastapi import FastAPI, APIRouter
import psycopg2

app = FastAPI()
router = APIRouter()

def get_conn():
    return psycopg2.connect(
        host="localhost", dbname="wigest", user="postgres", password="pass"
    )

@router.get("/stats")
def stats():
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM clients")
    nb_clients = cur.fetchone()[0]
    cur.execute("SELECT SUM(montant) FROM paiements")
    total_paiements = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM abonnements")
    nb_abonnements = cur.fetchone()[0]
    cur.close()
    conn.close()
    return {
        "nombre_clients": nb_clients,
        "total_paiements": total_paiements,
        "nombre_abonnements": nb_abonnements
    }

app.include_router(router)