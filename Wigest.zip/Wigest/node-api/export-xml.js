// export-xml.js
// Script Node.js pour exporter les données clients > abonnements > paiements en XML hiérarchisé
// Nécessite : npm install pg xmlbuilder2

const { Pool } = require('pg');
const { create } = require('xmlbuilder2');
const fs = require('fs');

const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'wigest',
  password: 'pass',
  port: 5432,
});

async function exportToXml() {
  const clients = await pool.query('SELECT * FROM clients');
  const root = create({ version: '1.0' }).ele('clients');

  for (const client of clients.rows) {
    const clientNode = root.ele('client', { id: client.id });
    clientNode.ele('nom').txt(client.nom);
    clientNode.ele('email').txt(client.email);

    // Abonnements
    const abos = await pool.query('SELECT * FROM abonnements WHERE client_id = $1', [client.id]);
    const abosNode = clientNode.ele('abonnements');
    for (const abo of abos.rows) {
      const aboNode = abosNode.ele('abonnement', { id: abo.id });
      aboNode.ele('offre').txt(abo.offre);
      aboNode.ele('date_debut').txt(abo.date_debut ? abo.date_debut.toISOString().split('T')[0] : '');
      aboNode.ele('date_fin').txt(abo.date_fin ? abo.date_fin.toISOString().split('T')[0] : '');

      // Paiements
      const paiements = await pool.query('SELECT * FROM paiements WHERE abonnement_id = $1', [abo.id]);
      const paiementsNode = aboNode.ele('paiements');
      for (const paiement of paiements.rows) {
        const paiementNode = paiementsNode.ele('paiement', { id: paiement.id });
        paiementNode.ele('montant').txt(paiement.montant.toString());
        paiementNode.ele('date_paiement').txt(paiement.date_paiement ? paiement.date_paiement.toISOString().split('T')[0] : '');
      }
    }
  }

  const xml = root.end({ prettyPrint: true });
  fs.writeFileSync('export_clients.xml', xml, 'utf8');
  console.log('Export terminé : export_clients.xml');
  await pool.end();
}

exportToXml().catch(console.error);
