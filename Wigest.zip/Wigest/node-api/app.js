const express = require('express');
const pool = require('./db');
const app = express();
app.use(express.json());

// Ajouter un abonnement
app.post('/abonnements', async (req, res) => {
  const { client_id, offre_id, date_debut, date_fin } = req.body;
  if (!client_id || !offre_id || !date_debut) {
    return res.status(400).json({ error: 'Champs client_id, offre_id et date_debut requis' });
  }
  try {
    const result = await pool.query(
      'INSERT INTO abonnements (client_id, offre_id, date_debut, date_fin) VALUES ($1, $2, $3, $4) RETURNING id',
      [client_id, offre_id, date_debut, date_fin || null]
    );
    res.json({ id: result.rows[0].id });
  } catch (e) {
    res.status(500).json({ error: 'Erreur lors de la création de l\'abonnement', details: e.message });
  }
});

//Lecture abonnements + paiements
app.get('/abonnements/:id', async (req, res) => {
  const { id } = req.params;
  const abn = await pool.query('SELECT a.*, o.nom AS offre_nom FROM abonnements a JOIN offres o ON a.offre_id = o.id WHERE a.id = $1',
  [id]);
  const paiements = await pool.query('SELECT * FROM paiements WHERE abonnement_id = $1', [id]);
  res.json({ abonnement: abn.rows[0], paiements: paiements.rows });
});
app.get('/abonnements/', async (req, res) => {
    const abn = await pool.query('SELECT * FROM abonnements');
    const paiements = await pool.query('SELECT * FROM paiements');
    res.json({ abonnement: abn.rows[0], paiements: paiements.rows });
  });

// Modifier un paiement
app.put('/paiements/:id', async (req, res) => {
  const { id } = req.params;
  const { montant, date_paiement } = req.body;
  await pool.query(
    'UPDATE paiements SET montant = $1, date_paiement = $2 WHERE id = $3',
    [montant, date_paiement, id]
  );
  res.json({ status: 'modifié' });
});

app.listen(3000, () => console.log('API Node.js sur port 3000'));